# MVP Optional Add‑Ons (All-in-one Bundle)

Includes:
1) **UI label swap patcher** (plain language across older pages)
2) **Advanced analytics** (project trends + summary + CSV reuse)
3) **Mobile-friendly refinements** (bigger tap targets, responsive tables)
4) **Self-service white-label** (branding DB + API + Settings page)
5) **Billing/PO** (PO capture + Stripe checkout placeholder)

## Install
```bash
unzip mvp_optional_addons_bundle.zip
```

### 1) Patch older UI labels
```bash
node scripts/patch_labels_field_friendly.js
```

### 2) Mount new APIs
In `server/routes.ts`, before `return httpServer;` add:
```ts
import analyticsRouter from "./routes/analytics";
import brandingRouter from "./routes/branding";
import billingRouter from "./routes/billing";

app.use("/api/analytics", analyticsRouter);
app.use("/api/branding", brandingRouter);
app.use("/api/billing", billingRouter);
```

### 3) Run SQL for branding & billing
```bash
psql "$DATABASE_URL" -f server/sql/branding.sql
psql "$DATABASE_URL" -f server/sql/billing.sql
```

### 4) Add pages (routes) in your client
```tsx
// Branding (org admin only)
import BrandingSettings from "./pages/BrandingSettings";
<Route path="/org/branding" element={<BrandingSettings />} />

// Billing (org admin only)
import BillingSettings from "./pages/BillingSettings";
<Route path="/billing" element={<BillingSettings />} />

// Advanced Analytics (manager/owner)
import AdvancedAnalytics from "./pages/AdvancedAnalytics";
<Route path="/analytics" element={<AdvancedAnalytics />} />
```

### 5) Mobile CSS
Include once in your app root (e.g., in `main.tsx`):
```ts
import "./styles/mobile.css";
```

### Env (optional for card checkout)
```
STRIPE_SECRET_KEY=sk_test_xxx
STRIPE_PRICE_ID=price_xxx
PUBLIC_URL=https://app.yourdomain.com
```

> If Stripe is not configured, the Billing page will gracefully show a message and still allow PO submission.
