export function touchAreaProps() {
  return { className: "min-h-[44px] min-w-[44px]" };
}
