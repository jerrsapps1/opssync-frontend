# Tenant Feature Gate (Per-tenant protection + UI auto-hide)

## What this does
- **Server**: Middleware `featureGate(...)` that blocks API access if a tenant doesn't have a feature.
- **Client**: Hook `useTenantFeatures()` to hide UI (like the RAG panel) when a feature is disabled.

## 1) Install
```bash
unzip tenant_feature_gate_bundle.zip
```

## 2) Harden your APIs
In `server/routes.ts` (or where you mount routes):
```ts
import { featureGate } from "./middleware/featureGate";
import managerRouter from "./routes/manager";
import slaRouter from "./routes/sla";

// Only allow if MANAGER or SLA is enabled for this tenant
app.use("/api/manager", featureGate("MANAGER", "SLA"), managerRouter);

// Only allow SLA endpoints when SLA enabled
app.use("/api/sla", featureGate("SLA"), slaRouter);
```

> This reads resolved per-tenant features via `resolveTenantFeatures(tenantId)`.
> If disabled, requests get 403 "Feature disabled for tenant".

## 3) Auto-hide UI in your Dashboard
In your Dashboard page where you render the merged RAG panel:
```tsx
import DashboardRAGPanel from "../partials/DashboardRAGPanel";
import { useTenantFeatures } from "../hooks/useTenantFeatures";

export default function Dashboard() {
  const { features, loading } = useTenantFeatures();
  const showRAG = !!features?.SLA || !!features?.MANAGER;

  return (
    <div className="space-y-6">
      {/* ... existing content ... */}
      {!loading && showRAG ? <DashboardRAGPanel /> : null}
    </div>
  );
}
```

## 4) Notes
- Auth must put `{ tenantId }` on `req.user`.
- The gate merges global owner flags + tenant overrides (from your earlier bundle).
- If you have multiple environments, you can keep defaults off globally and let tenants override on demand.
