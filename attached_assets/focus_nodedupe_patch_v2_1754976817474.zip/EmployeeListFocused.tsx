
// Example focused employee list component
import React from 'react';

export default function EmployeeListFocused() {
  return <div>Focused Employee List Component</div>;
}
