import React from "react";
import { useParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

type Employee = { id: string; name: string; role?: string; phone?: string; email?: string; certs?: string };

async function fetchEmployee(id: string): Promise<Employee> {
  const r = await apiRequest("GET", `/api/employees/${id}`);
  return r.json();
}
async function updateEmployee(e: Employee) {
  const r = await apiRequest("PATCH", `/api/employees/${e.id}`, e);
  return r.json();
}

export default function EmployeeDetail() {
  const { id } = useParams();
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["employee", id], queryFn: () => fetchEmployee(id!), enabled: !!id });
  const [form, setForm] = React.useState<Employee | null>(null);
  React.useEffect(() => { if (data) setForm(data); }, [data]);
  const save = useMutation({ mutationFn: updateEmployee, onSuccess: () => qc.invalidateQueries() });

  if (isLoading || !form) return <div className="p-6 text-gray-400">Loading…</div>;

  return (
    <div className="p-6 space-y-3">
      <div className="text-lg font-semibold">Employee Profile</div>
      <div className="grid sm:grid-cols-2 gap-3">
        <Input value={form.name} onChange={(e)=>setForm({...form, name:e.target.value})} placeholder="Name" />
        <Input value={form.role || ""} onChange={(e)=>setForm({...form, role:e.target.value})} placeholder="Role" />
        <Input value={form.email || ""} onChange={(e)=>setForm({...form, email:e.target.value})} placeholder="Email" />
        <Input value={form.phone || ""} onChange={(e)=>setForm({...form, phone:e.target.value})} placeholder="Phone" />
        <Input value={form.certs || ""} onChange={(e)=>setForm({...form, certs:e.target.value})} placeholder="Certifications" />
      </div>
      <div className="pt-2">
        <Button onClick={()=>save.mutate(form)} disabled={save.isPending}>Save</Button>
      </div>
    </div>
  );
}
