import React from "react";
import { NavLink, Outlet } from "react-router-dom";

export default function SettingsIndex() {
  const Item = ({ to, children }: { to: string; children: React.ReactNode }) => (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `px-3 py-2 rounded-[var(--brand-radius)] text-sm mr-2 ${isActive ? "bg-[color:var(--brand-primary)] text-white" : "bg-gray-800 text-gray-200 hover:brightness-110"}`
      }
    >
      {children}
    </NavLink>
  );

  return (
    <div className="p-4">
      <h1 className="text-xl font-semibold mb-3">Settings</h1>
      <div className="mb-4">
        <Item to="projects">Project Details</Item>
        <Item to="equipment">Equipment</Item>
        <Item to="employees">Employees</Item>
      </div>
      <div className="rounded border border-gray-800 bg-[#0b1220]">
        <Outlet />
      </div>
    </div>
  );
}
