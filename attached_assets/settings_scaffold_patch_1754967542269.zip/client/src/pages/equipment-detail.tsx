import React from "react";
import { useParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

type Equipment = { id: string; name: string; type: string; make?: string; model?: string; year?: number; serialNumber?: string; notes?: string };

async function fetchEquipment(id: string): Promise<Equipment> {
  const r = await apiRequest("GET", `/api/equipment/${id}`);
  return r.json();
}
async function updateEquipment(e: Equipment) {
  const r = await apiRequest("PATCH", `/api/equipment/${e.id}`, e);
  return r.json();
}

export default function EquipmentDetail() {
  const { id } = useParams();
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["equipment", id], queryFn: () => fetchEquipment(id!), enabled: !!id });
  const [form, setForm] = React.useState<Equipment | null>(null);
  React.useEffect(() => { if (data) setForm(data); }, [data]);
  const save = useMutation({ mutationFn: updateEquipment, onSuccess: () => qc.invalidateQueries() });

  if (isLoading || !form) return <div className="p-6 text-gray-400">Loading…</div>;

  return (
    <div className="p-6 space-y-3">
      <div className="text-lg font-semibold">Equipment Profile</div>
      <div className="grid sm:grid-cols-2 gap-3">
        <Input value={form.name} onChange={(e)=>setForm({...form, name:e.target.value})} placeholder="Name" />
        <Input value={form.type} onChange={(e)=>setForm({...form, type:e.target.value})} placeholder="Type" />
        <Input value={form.make || ""} onChange={(e)=>setForm({...form, make:e.target.value})} placeholder="Make" />
        <Input value={form.model || ""} onChange={(e)=>setForm({...form, model:e.target.value})} placeholder="Model" />
        <Input value={String(form.year||"")} onChange={(e)=>setForm({...form, year:Number(e.target.value)||undefined})} placeholder="Year" />
        <Input value={form.serialNumber || ""} onChange={(e)=>setForm({...form, serialNumber:e.target.value})} placeholder="Serial #" />
      </div>
      <div className="pt-2">
        <Button onClick={()=>save.mutate(form)} disabled={save.isPending}>Save</Button>
      </div>
    </div>
  );
}
