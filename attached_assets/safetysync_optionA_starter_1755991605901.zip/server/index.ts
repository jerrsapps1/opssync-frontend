import express, { Request, Response } from "express";
import path from "path";

const app = express();
app.use(express.json());

// --- Health/ping routes ---
app.get("/api/ping", (_req: Request, res: Response) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

// Example: database check stub (replace with real DB later)
app.get("/api/db-check", (_req: Request, res: Response) => {
  res.json({ database: "ok (stub)" });
});

// --- Static serve in production (optional) ---
// When you `vite build`, client files live in dist/client
const clientDist = path.join(process.cwd(), "dist", "client");
app.use(express.static(clientDist));
app.get("*", (_req: Request, res: Response) => {
  res.sendFile(path.join(clientDist, "index.html"));
});

const PORT = process.env.PORT ? Number(process.env.PORT) : 5000;
app.listen(PORT, () => {
  console.log(`[express] serving on port ${PORT}`);
});