# SafetySync.ai — Option A Starter (client/server)

A minimal, production-friendly setup for React (Vite) + Express with a clean separation:

- `client/` — React app (Vite dev server on :5173)
- `server/` — Express API (Node on :5000)
- Vite dev proxy forwards `/api/*` → `http://localhost:5000`

## Run on Replit (or locally)

1) Open the shell and install deps:
```
npm install
```

2) Start both servers:
```
npm run dev
```
- Frontend: http://localhost:5173
- API: http://localhost:5000
- Test API: http://localhost:5173/api/ping (proxied) or http://localhost:5000/api/ping

## Build for production
```
npm run build
```
Then the Express server serves `dist/client` automatically.

## Common fixes

- **Vite can't find /src/main.tsx**: Ensure your files live in `/client/src` and `vite.config.ts` sets `root: "client"`.
- **CORS in prod**: Since Express serves the built client, CORS is avoided. If you split hosting, add CORS middleware on the API.
- **Secrets**: Keep them in Replit's Secrets. Do not commit `.env`.

Enjoy! 🚀