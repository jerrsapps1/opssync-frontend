import React from "react";

export default function App() {
  return (
    <div style={{ padding: 24, fontFamily: 'system-ui, Arial, sans-serif' }}>
      <h1>SafetySync.ai</h1>
      <p>Vite + React + Express are wired up.</p>
      <p>Try calling the API: <code>/api/ping</code></p>
    </div>
  );
}