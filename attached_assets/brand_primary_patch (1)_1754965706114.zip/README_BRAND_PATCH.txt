Brand Primary Patch
-------------------
This patch converts key UI colors to use your white-label CSS variables so the theme updates app-wide:

Changed files:
- client/src/components/assignments/employee-list.tsx
- client/src/components/assignments/equipment-list.tsx

What changed:
- Replaced hardcoded blues/purples with CSS vars:
  - var(--brand-primary) for normal card backgrounds and focus rings
  - var(--brand-accent) for drag state, icons, and chips
- Kept all drag-and-drop logic intact.

Requires:
- The global theme variables are applied by useBrandTheme (from the previous layout zip).
  If you haven't added it yet, install the 'app_layout_with_topbar.zip' package first.

Tailwind usage:
- We use arbitrary color values: bg-[color:var(--brand-primary)]
- This works with Tailwind JIT. No config changes needed.

Rollback:
- If you need to revert, re-apply your original files or replace the var(...) classes with your color classes.
